# FinanceDataReader MCP 서버 러닝 가이드 (KR + Overseas)

## 🎯 목적
FinanceDataReader(FDR)을 사용해 **전세계 주식/지수/환율(일봉)** 데이터를 MCP 툴로 제공합니다.  
과거 **Kiwoom 기반 가이드**는 폐기되었습니다. 이 서버는 **인증/토큰 불필요**, 일봉/리스트/검색 중심입니다.

## 🧱 폴더 구조
```
financedatareader/
├── __init__.py
├── client.py    # FDR 어댑터(데이터 조회/가공)
├── server.py    # MCP 서버(툴 등록, run_server 엔트리)
└── LEARNING_GUIDE.md
```

## 🚀 실행
```bash
# 권장: Python 3.12+, mise + uv
python server.py    # 또는: python -m financedatareader.server
# 기본: http://0.0.0.0:8030
```

## 🛠 제공 툴
- `get_stock_basic_info(stock_code)`  
  - 마지막 일봉 2개로 등락/등락률 계산 포함 요약 (실시간 아님)
- `get_stock_info(stock_code, market=None)`  
  - 한국(KRX) 우선, 없으면 미국(NYSE/NASDAQ/AMEX/S&P500)에서 탐색
- `get_stock_list(markets="KRX" | ["NASDAQ","S&P500", ...])`  
  - 다중 시장 동시 지원, 표준화된 리스트 반환
- `get_daily_chart(stock_code, start_date=None, end_date=None)`  
  - 일봉 OHLCV, `YYYYMMDD`/`YYYY-MM-DD` 모두 허용
- `search_stock_by_name(query, markets=("KRX",), limit=None)`  
  - 이름/심볼 부분검색, 다중 시장 가능
- `get_market_overview(region="KR"|"US")`  
  - KR: KS11/KQ11, US: DJI/US500/IXIC 요약
- `get_market_status(region="KR"|"US")`  
  - KR은 09:00~15:30 기준, US는 DST/타임존 이슈로 `UNKNOWN`

**미지원(명시 에러 반환)**: `get_minute_chart`, `get_stock_orderbook`, `get_stock_execution_info`, `get_price_change_ranking`, `get_volume_top_ranking`, `get_foreign_trading_trend`

## 🧩 설계 포인트
- **클라이언트/서버 분리**: `client.py`(데이터 로직) ↔ `server.py`(툴 등록)
- **TTL 캐시(5분)**: 불필요한 원격 호출 감소
- **표준 에러**: 도메인 외 요청은 `NOT_SUPPORTED` 등 명확한 코드로 응답
- **해외 정식 지원**: 리스트/검색/시장 개요까지 확장

## 🔍 테스트 팁
- MCP 호스트에서 `list_tools` → 위 툴 목록이 보여야 정상
- `get_daily_chart("AAPL","2024-01-01","2024-12-31")` 등으로 범용 확인