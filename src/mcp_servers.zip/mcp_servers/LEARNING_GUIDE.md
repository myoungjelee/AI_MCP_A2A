# 📘 LEARNING_GUIDE (MCP 서버 개발 가이드)

이 문서는 프로젝트 전체 MCP 서버 개발과 실행을 위한 러닝 가이드입니다.  
기존 FastMCP 전역 @app.tool 패턴은 폐기되었으며, 현재는 **BaseMCPServer + @self.mcp.tool + run_server()** 패턴으로 통일되어 있습니다.

---

## 1. MCP 서버 개발 철학
- **단일 책임**: 서버별 도메인 분리 (예: FinanceDataReader, News, Macro 등)
- **AI-First Design**: 입력/출력 구조를 명확히 정의 → LLM이 안정적으로 호출 가능
- **마이크로서비스 아키텍처**: 각 MCP 서버는 독립 실행/배포 가능, 포트만 다르게 운영

---

## 2. 개발 순서 (학습 단계)
1. **Phase 1**: `BaseMCPServer` 구조 이해  
   - 로깅, 미들웨어, 표준 응답(`create_standard_response`, `create_error_response`)  
2. **Phase 2**: 간단한 서버 (예: `financedatareader`)로 MCP 툴 호출 학습  
3. **Phase 3**: 분석형 서버 (`stock_analysis`, `financial_analysis`)와 외부 API 서버 (`naver_news`, `tavily_search`) 실습  
4. **Phase 4**: 통합 및 운영  
   - 헬스/메트릭 확인, 에러 처리 통일, TTL 캐시 적용, Docker Compose 기반 멀티 서버 실행

---

## 3. 공통 아키텍처 패턴
- **예외 처리**: 모든 실패는 `create_error_response`로 구조화 (예: `NOT_SUPPORTED`, `VALIDATION_ERROR`)  
- **TTL 캐시**: 5분 기본 캐시로 과도한 API 호출 방지  
- **헬스체크 & 메트릭**: `get_server_health`, `get_server_metrics` 툴 기본 포함  
- **로그 구조화**: debug 모드에서는 traceback, release 모드에서는 요약 메시지만 출력

---

## 4. MCP 서버별 툴 (최신)
### financedatareader (8030)
- `get_stock_basic_info(stock_code)`  
- `get_stock_info(stock_code, market=None)`  
- `get_stock_list(markets="KRX"|["NASDAQ","S&P500"])`  
- `get_daily_chart(stock_code, start_date, end_date)`  
- `search_stock_by_name(query, markets, limit)`  
- `get_market_overview(region="KR"|"US")`  
- `get_market_status(region="KR"|"US")`  
- (미지원 명시): `get_minute_chart`, `get_stock_orderbook`, `get_stock_execution_info`, `get_price_change_ranking`, `get_volume_top_ranking`, `get_foreign_trading_trend`

### financial_analysis (8031)
- `get_financial_data(symbol, data_type)`  
- `calculate_financial_ratios(symbol)`  
- `perform_dcf_valuation(symbol, growth_rate, discount_rate)`  
- `generate_investment_report(symbol)`

### macroeconomic (8032)
- `collect_data(category, max_records, source)`  
- `process_data_batch(data_records, operation)`  
- `analyze_data_trends(data_records)`

### naver_news (8033)
- `search_news_articles(query, max_articles, sort_by)`  
- `get_stock_news(symbol, company_name, days_back, max_articles)`

### stock_analysis (8034)
- `analyze_data_trends(symbol, period)`  
- `calculate_statistical_indicators(symbol)`  
- `perform_pattern_recognition(symbol)`

### tavily_search (8035)
- `search_web(query, max_results)`  
- `search_news(query, max_results)`  
- `search_finance(query, max_results)`

### 공통 (모든 MCP 서버)
- `get_server_health`  
- `get_server_metrics`

---

## 5. 실행법
각 폴더(`financedatareader/`, `financial_analysis/`, ...)에서:
```bash
python server.py
# 또는
python -m <패키지명>.server
```
- 포트는 서버별로 다르게 설정 (`8030`~`8035`)  
- 종료: `Ctrl+C`

---

## 6. 테스트 & 디버깅
- `list_tools` 호출 → 위 툴 목록 확인  
- `call_tool("get_stock_basic_info", {"stock_code":"AAPL"})` 같은 단위 테스트  
- 헬스체크: `get_server_health` 호출 시 `{ "status": "ok" }` 확인

---

## 7. 실무 적용
- **운영 환경 최적화**: 캐싱, 세션 풀링, 회로 차단기  
- **보안**: API 키는 `.env`로 분리, HTTPS/TLS 적용  
- **확장성**: Docker Compose로 멀티 MCP 서버 실행, 필요 시 Kubernetes로 확장 가능

---

✅ 이 문서는 프로젝트 최상위 공통 가이드이며, 각 폴더별 `LEARNING_GUIDE.md`는 세부 도메인 설명을 포함합니다.