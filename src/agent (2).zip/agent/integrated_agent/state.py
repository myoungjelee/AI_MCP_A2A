"""통합 에이전트 상태 및 헬퍼들"""

from __future__ import annotations

from typing import Annotated, Dict, List, Literal, TypedDict

from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages

StepName = Literal["validate", "collect", "analyze", "decide", "respond", "idle"]


class IntegratedAgentState(TypedDict, total=False):
    # 대화 메시지
    messages: Annotated[List[BaseMessage], add_messages]

    # 사용자 입력
    question: str

    # 파이프라인 진행 상태
    current_step: StepName
    step_servers: List[str]

    # 검증 결과
    is_investment_related: bool

    # 수집 결과
    collected_data: Dict
    data_collection_status: Literal["pending", "completed", "error"]
    data_quality_score: float

    # 분석 결과
    analysis_result: Dict
    analysis_confidence: float
    key_insights: List[str]

    # 최종 응답
    final_response: str
    response_type: Literal["analysis", "error"]

    # 진단/로그
    warnings: List[str]
    errors: List[str]


def _ensure_lists(state: IntegratedAgentState) -> None:
    if "warnings" not in state:
        state["warnings"] = []
    if "errors" not in state:
        state["errors"] = []


def update_current_step(
    state: IntegratedAgentState, step: StepName, servers: List[str] | None = None
) -> IntegratedAgentState:
    new_state = dict(state)
    new_state["current_step"] = step
    if servers is not None:
        new_state["step_servers"] = list(servers)
    _ensure_lists(new_state)  # 보조 필드 보장
    return new_state  # LangGraph는 불변성 유지 권장


def add_warning(state: IntegratedAgentState, msg: str) -> IntegratedAgentState:
    new_state = dict(state)
    _ensure_lists(new_state)
    new_state["warnings"].append(msg)
    return new_state


def add_error(
    state: IntegratedAgentState, msg: str, code: str | None = None
) -> IntegratedAgentState:
    new_state = dict(state)
    _ensure_lists(new_state)
    if code:
        new_state["errors"].append(f"{code}: {msg}")
    else:
        new_state["errors"].append(msg)
    return new_state


def create_initial_state(
    question: str, session_id: str | None = None
) -> IntegratedAgentState:
    """초기 상태 생성"""

    return {
        "question": question,
        "current_step": "idle",
        "step_servers": [],
        "is_investment_related": False,
        "collected_data": {},
        "data_collection_status": "pending",
        "data_quality_score": 0.0,
        "analysis_result": {},
        "analysis_confidence": 0.0,
        "key_insights": [],
        "final_response": "",
        "response_type": "analysis",
        "warnings": [],
        "errors": [],
        "messages": [],
    }


def set_processing_end_time(state: IntegratedAgentState) -> IntegratedAgentState:
    """처리 완료 시간 설정"""
    from datetime import datetime

    new_state = dict(state)
    new_state["processing_end_time"] = datetime.now().isoformat()
    return new_state
