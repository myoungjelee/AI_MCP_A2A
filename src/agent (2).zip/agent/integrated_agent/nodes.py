"""통합 에이전트 노드 (financial_analysis 우선, freshness 파라미터 추가)"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_ollama import ChatOllama

from ..base import (
    SERVER_TOOLS_ALLOWLIST,
    select_servers_for_collection,
    select_tools_for_server,
)
from ..base.mcp_config import MCPServerConfig
from .state import IntegratedAgentState, add_error, add_warning, update_current_step
from .validation import InvestmentQuestionValidator, validate_investment_question


class IntegratedAgentNodes:
    """통합 에이전트 노드 구현 (fresh-first)"""

    def __init__(self, model_name: str = "gpt-oss:20b"):
        self.model_name = model_name
        try:
            self.llm = ChatOllama(
                model=model_name,
                base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
                temperature=0.7,
                timeout=30,
            )
        except Exception as e:
            print(f"ChatOllama 초기화 실패: {e}")
            raise

        self.validator = InvestmentQuestionValidator(model_name)
        self.mcp_client: Optional[MultiServerMCPClient] = None
        self.mcp_tools_dict: Dict[str, Any] = {}

    async def initialize_mcp_tools(self) -> bool:
        try:
            server_configs = MCPServerConfig.get_standard_servers()
            self.mcp_client = MultiServerMCPClient(server_configs)
            tools = await asyncio.wait_for(self.mcp_client.get_tools(), timeout=10.0)
            for tool in tools:
                self.mcp_tools_dict[tool.name] = tool
            return True
        except Exception as e:
            print(f"MCP 도구 초기화 실패: {e}")
            self.mcp_client = None
            return False

    async def validate_node(self, state: IntegratedAgentState) -> IntegratedAgentState:
        try:
            new_state = update_current_step(state, "validate")
            return await validate_investment_question(new_state, self.validator)
        except Exception as e:
            error_state = add_error(
                state, f"질문 검증 중 오류: {str(e)}", "VALIDATION_ERROR"
            )
            error_state["is_investment_related"] = False
            error_state["final_response"] = (
                "질문 검증 중 오류가 발생했습니다. 다시 시도해주세요."
            )
            error_state["response_type"] = "error"
            return error_state

    async def collect_node(self, state: IntegratedAgentState) -> IntegratedAgentState:
        try:
            if not state["is_investment_related"]:
                return state

            new_state = update_current_step(state, "collect")

            # fresh-first: financial_analysis를 항상 맨 앞에 오도록 보정
            selected = select_servers_for_collection(state["question"])
            selected = ["financial_analysis"] + [
                s for s in selected if s != "financial_analysis"
            ]

            new_state = update_current_step(new_state, "collect", selected)

            tasks = [self._collect_from_server(s, state["question"]) for s in selected]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            collected: Dict[str, Any] = {}
            for server, result in zip(selected, results, strict=False):
                if isinstance(result, Exception):
                    new_state = add_warning(new_state, f"{server} 수집 실패: {result}")
                    collected[server] = {"error": str(result), "status": "failed"}
                else:
                    collected[server] = result

            new_state["collected_data"] = collected
            new_state["data_collection_status"] = "completed"
            new_state["data_quality_score"] = self._calculate_data_quality(collected)
            return new_state
        except Exception as e:
            return add_error(
                state, f"데이터 수집 중 오류: {str(e)}", "COLLECTION_ERROR"
            )

    async def analyze_node(self, state: IntegratedAgentState) -> IntegratedAgentState:
        try:
            if not state["is_investment_related"]:
                return state

            new_state = update_current_step(state, "analyze")
            analysis_servers = await self._select_mcp_servers_for_analysis(
                state["question"]
            )
            # fresh-first 보정
            analysis_servers = ["financial_analysis"] + [
                s for s in analysis_servers if s != "financial_analysis"
            ]

            new_state = update_current_step(new_state, "analyze", analysis_servers)

            collected_data = state["collected_data"]
            tasks = [
                self._analyze_with_server(s, collected_data, state["question"])
                for s in analysis_servers
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            analysis_results: Dict[str, Any] = {}
            for server, result in zip(analysis_servers, results, strict=False):
                if isinstance(result, Exception):
                    new_state = add_warning(new_state, f"{server} 분석 실패: {result}")
                    analysis_results[server] = {
                        "error": str(result),
                        "status": "failed",
                    }
                else:
                    analysis_results[server] = result

            integrated = await self._integrate_analysis_results(
                analysis_results, state["question"]
            )
            new_state["analysis_result"] = integrated
            new_state["analysis_confidence"] = integrated.get("confidence", 0.7)
            new_state["key_insights"] = integrated.get("insights", [])
            return new_state
        except Exception as e:
            return add_error(state, f"데이터 분석 중 오류: {str(e)}", "ANALYSIS_ERROR")

    async def decide_node(self, state: IntegratedAgentState) -> IntegratedAgentState:
        try:
            if not state["is_investment_related"]:
                return state

            new_state = update_current_step(state, "decide")
            decision_servers = ["financial_analysis"]
            new_state = update_current_step(new_state, "decide", decision_servers)

            decision_prompt = self._create_decision_prompt(
                state["question"], state["analysis_result"], state["collected_data"]
            )
            response = await self.llm.ainvoke(
                [
                    SystemMessage(
                        content="당신은 투자 의사결정 전문가입니다. 데이터와 분석을 바탕으로 명확한 결론을 제시하세요."
                    ),
                    HumanMessage(content=decision_prompt),
                ]
            )
            new_state["analysis_result"]["decision"] = response.content
            return new_state
        except Exception as e:
            return add_error(state, f"의사결정 중 오류: {str(e)}", "DECISION_ERROR")

    async def respond_node(self, state: IntegratedAgentState) -> IntegratedAgentState:
        try:
            if not state["is_investment_related"]:
                return state

            new_state = update_current_step(state, "respond")
            final = await self._generate_final_response(
                new_state,
                state["question"],
                state["analysis_result"],
                state["collected_data"],
                state["key_insights"],
            )
            new_state["final_response"] = final
            new_state["response_type"] = "analysis"
            return new_state
        except Exception as e:
            error_state = add_error(
                state, f"응답 생성 중 오류: {str(e)}", "RESPONSE_ERROR"
            )
            error_state["final_response"] = (
                "응답 생성 중 오류가 발생했습니다. 다시 시도해주세요."
            )
            error_state["response_type"] = "error"
            return error_state

    # === 내부 ===

    async def _select_mcp_servers_for_analysis(self, question: str) -> List[str]:
        return ["financial_analysis", "stock_analysis", "financedatareader"]

    async def _collect_from_server(self, server: str, question: str) -> Dict[str, Any]:
        try:
            if not self.mcp_client:
                await self.initialize_mcp_tools()

            tools = select_tools_for_server(server, question)
            available = [t for t in tools if t in self.mcp_tools_dict]

            collected: Dict[str, Any] = {}
            if available:
                tasks = []
                for tool_name in available:
                    params = self._create_tool_params(tool_name, question)
                    tasks.append(
                        (tool_name, self.mcp_tools_dict[tool_name].ainvoke(params))
                    )
                results = await asyncio.gather(
                    *[t for _, t in tasks], return_exceptions=True
                )
                for (tool_name, _), res in zip(tasks, results, strict=False):
                    if isinstance(res, Exception):
                        collected[tool_name] = {"error": str(res)}
                    else:
                        collected[tool_name] = res

            return {
                "server": server,
                "timestamp": datetime.now().isoformat(),
                "data": collected,
                "status": "success" if collected else "partial",
                "tools_used": list(collected.keys()),
            }
        except Exception as e:
            return {
                "server": server,
                "timestamp": datetime.now().isoformat(),
                "data": {},
                "status": "error",
                "error": str(e),
            }

    async def _analyze_with_server(
        self, server: str, data: Dict[str, Any], question: str
    ) -> Dict[str, Any]:
        try:
            if not self.mcp_client:
                await self.initialize_mcp_tools()

            analysis_tools = self._select_analysis_tools_for_server(server, question)
            results: Dict[str, Any] = {}
            for tool_name in analysis_tools:
                if tool_name in self.mcp_tools_dict:
                    try:
                        params = self._create_analysis_params(tool_name, data, question)
                        res = await self.mcp_tools_dict[tool_name].ainvoke(params)
                        results[tool_name] = res
                    except Exception as e:
                        results[tool_name] = {"error": str(e)}
            return {
                "server": server,
                "analysis": results,
                "confidence": 0.8,
                "insights": self._extract_insights_from_analysis(results),
                "tools_used": list(results.keys()),
            }
        except Exception as e:
            return {
                "server": server,
                "analysis": {},
                "confidence": 0.0,
                "error": str(e),
                "insights": [],
            }

    def _calculate_data_quality(self, data: Dict[str, Any]) -> float:
        if not data:
            return 0.0
        ok = sum(1 for d in data.values() if d.get("status") == "success")
        total = len(data)
        return ok / total if total else 0.0

    def _create_decision_prompt(
        self, question: str, analysis: Dict[str, Any], data: Dict[str, Any]
    ) -> str:
        return f"""
**질문**: {question}

**분석 결과**:
- 신뢰도: {analysis.get('confidence', 0)}
- 핵심 인사이트: {analysis.get('integrated_insights', [])}

**수집된 데이터**:
{data}

위 정보를 종합하여 명확한 투자 의사결정 및 권고사항을 제시해주세요.
"""

    def _fresh_params(self) -> Dict[str, Any]:
        """모든 MCP 호출에 공통으로 붙일 freshness 힌트 (서버가 지원할 때만 사용됨)."""
        return {
            "force_refresh": True,
            "no_cache": True,
            "as_of": datetime.now().isoformat(),
        }

    def _create_tool_params(self, tool_name: str, question: str) -> Dict[str, Any]:
        base = self._fresh_params()
        if tool_name in ["search_news_articles", "search_web"]:
            base.update({"query": question})
        elif tool_name in ("get_stock_basic_info", "get_stock_info"):
            base.update({"stock_code": "005930"})
        elif tool_name == "get_daily_chart":
            base.update(
                {
                    "stock_code": "005930",
                    "start_date": "2024-01-01",
                    "end_date": "2025-01-01",
                }
            )
        elif tool_name == "get_market_status":
            pass
        elif tool_name == "search_stock_by_name":
            base.update({"query": "삼성전자"})
        elif tool_name == "get_financial_data":
            base.update({"symbol": "005930"})
        elif tool_name == "calculate_financial_ratios":
            base.update({"company_code": "005930", "period": "quarterly"})
        return base

    def _select_analysis_tools_for_server(
        self, server: str, question: str
    ) -> List[str]:
        if server == "financial_analysis":
            return ["calculate_financial_ratios", "perform_dcf_valuation"]
        elif server == "stock_analysis":
            return ["analyze_data_trends", "calculate_statistical_indicators"]
        else:
            return SERVER_TOOLS_ALLOWLIST.get(server, [])[:1]

    def _create_analysis_params(
        self, tool_name: str, data: Dict[str, Any], question: str
    ) -> Dict[str, Any]:
        base = self._fresh_params()
        if tool_name == "calculate_financial_ratios":
            base.update({"company_code": "005930", "period": "quarterly"})
        elif tool_name == "analyze_data_trends":
            base.update({"stock_code": "005930", "period_days": 30})
        elif tool_name == "perform_dcf_valuation":
            base.update({"stock_code": "005930"})
        return base

    def _extract_insights_from_analysis(
        self, analysis_results: Dict[str, Any]
    ) -> List[str]:
        insights: List[str] = []
        for tool_name, res in analysis_results.items():
            if isinstance(res, dict) and "error" not in res:
                insights.append(f"{tool_name} 분석 완료")
            elif isinstance(res, dict) and "error" in res:
                insights.append(f"{tool_name} 분석 실패: {res['error']}")
        return insights

    async def _integrate_analysis_results(
        self, results: Dict[str, Any], question: str
    ) -> Dict[str, Any]:
        insights: List[str] = []
        total, cnt = 0.0, 0
        for r in results.values():
            if "insights" in r:
                insights.extend(r["insights"])
            if "confidence" in r:
                total += r["confidence"]
                cnt += 1
        conf = total / cnt if cnt else 0.5
        return {
            "question": question,
            "integrated_insights": insights,
            "confidence": conf,
            "server_results": results,
            "timestamp": datetime.now().isoformat(),
        }

    async def _generate_final_response(
        self,
        state: IntegratedAgentState,
        question: str,
        analysis: Dict[str, Any],
        data: Dict[str, Any],
        insights: List[str],
    ) -> str:
        """최종 마크다운 응답 생성"""

        response_prompt = f"""
사용자 질문: {question}

분석 결과와 데이터를 바탕으로 전문적인 투자 분석 보고서를 마크다운 형식으로 작성해주세요.

**포함할 내용**:
1. 📊 **핵심 요약**
2. 📈 **상세 분석**
3. 💡 **주요 인사이트**
4. ⚠️ **리스크 요인**
5. 🎯 **투자 권고**

**분석 데이터**: {analysis}
**수집 데이터**: {data}
**핵심 인사이트**: {insights}

전문적이고 구체적인 분석을 제공하되, 이해하기 쉽게 작성해주세요.
"""

        # ChatOllama 공식 문서 기반 호출 패턴
        try:
            print(f"LLM 호출 시작: model={self.model_name}")

            # LangGraph 표준 메시지 구성 (이전 대화 자동 포함)
            messages = state.get("messages", [])

            # 시스템 메시지가 없으면 추가
            if not messages or not isinstance(messages[0], SystemMessage):
                messages.insert(
                    0,
                    SystemMessage(
                        content="당신은 전문 투자 분석가입니다. 마크다운 형식으로 체계적이고 이해하기 쉬운 투자 분석 보고서를 작성하세요."
                    ),
                )

            # 현재 질문 추가
            messages.append(HumanMessage(content=response_prompt))

            # ainvoke 호출 (공식 문서 패턴)
            response = await self.llm.ainvoke(messages)

            print(f"LLM 호출 성공: {len(response.content)} 문자")

            # 응답을 메시지 히스토리에 추가 (LangGraph 표준)
            new_state = state.copy()
            new_state["messages"] = messages + [AIMessage(content=response.content)]

            return response.content

        except Exception as e:
            print(f"LLM 호출 실패: {type(e).__name__}: {e}")
            # 연결 문제인지 확인
            if "connect" in str(e).lower() or "timeout" in str(e).lower():
                print(
                    f"Ollama 연결 문제 감지. BASE_URL: {os.getenv('OLLAMA_BASE_URL')}"
                )
            import traceback

            print(f"Full traceback: {traceback.format_exc()}")

            # 에러 상태 반환
            error_state = add_error(
                state, f"응답 생성 중 오류: {str(e)}", "RESPONSE_ERROR"
            )
            error_state["final_response"] = (
                "응답 생성 중 오류가 발생했습니다. 다시 시도해주세요."
            )
            error_state["response_type"] = "error"
            return error_state
