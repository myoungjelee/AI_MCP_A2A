"""질문 검증 로직 (LangGraph 0.6.x 호환)"""

from __future__ import annotations

from dataclasses import dataclass

from .state import IntegratedAgentState, add_error


@dataclass
class InvestmentQuestionValidator:
    model_name: str = "gpt-oss:20b"

    async def avalidate(self, question: str) -> bool:
        """간단한 규칙 + 향후 LLM 검증기로 확장 가능하도록 비동기 인터페이스 유지.
        투자/주식/재무/뉴스/인덱스 관련 키워드가 있으면 투자 관련으로 간주.
        """
        if not question:
            return False
        q = question.lower()
        heuristics = [
            "투자",
            "주식",
            "재무",
            "영업이익",
            "실적",
            "밸류",
            "valuation",
            "dcf",
            "kospi",
            "kosdaq",
            "나스닥",
            "nasdaq",
            "s&p",
            "sp500",
            "금리",
            "cpi",
            "ppi",
            "gdp",
            "환율",
            "지수",
            "etf",
            "선물",
            "옵션",
            "캔들",
            "차트",
            "ohlc",
            "종목",
            "티커",
            "ticker",
        ]
        return any(k in q for k in heuristics)


async def validate_investment_question(
    state: IntegratedAgentState, validator: InvestmentQuestionValidator
) -> IntegratedAgentState:
    try:
        q = (state.get("question") or "").strip()
        is_related = await validator.avalidate(q)
        new_state = dict(state)
        new_state["is_investment_related"] = bool(is_related)
        return new_state
    except Exception as e:
        return add_error(state, f"검증 실패: {e}", "VALIDATION_ERROR")
