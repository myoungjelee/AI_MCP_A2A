"""LangGraph 에이전트 기본 클래스"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

from langchain_core.runnables import RunnableConfig
from langgraph.graph import StateGraph

from .base_graph_state import BaseGraphState


class BaseGraphAgent(ABC):
    """모든 LangGraph 에이전트가 상속하는 공통 베이스"""

    def __init__(self) -> None:
        self._graph = self._build_graph()

    @abstractmethod
    def _build_graph(self) -> StateGraph:
        """그래프 구성 (각 에이전트가 구현)"""
        raise NotImplementedError

    async def arun(
        self, state: BaseGraphState, *, config: Optional[RunnableConfig] = None
    ) -> Dict[str, Any]:
        run_graph = self._graph.compile()
        return await run_graph.ainvoke(state, config=config)
