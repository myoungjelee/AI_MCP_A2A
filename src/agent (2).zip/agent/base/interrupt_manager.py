"""에이전트 인터럽트/타임아웃 유틸"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Callable, Optional


class InterruptError(Exception):
    pass


class TimeoutError(Exception):
    pass


@dataclass
class InterruptCallbackHandler:
    on_interrupt: Optional[Callable[[], None]] = None


class TimeoutManager:
    """단순 타임아웃 컨텍스트"""

    def __init__(self, seconds: float) -> None:
        self.seconds = seconds

    async def run(self, coro):
        return await asyncio.wait_for(coro, timeout=self.seconds)


class InterruptManager:
    """에이전트 인터럽트 상태 관리"""

    def __init__(self) -> None:
        self._interrupted: bool = False
        self._count: int = 0

    def interrupt(self) -> None:
        self._interrupted = True
        self._count += 1

    @property
    def is_interrupted(self) -> bool:
        return self._interrupted

    @property
    def interrupt_count(self) -> int:
        return self._count
