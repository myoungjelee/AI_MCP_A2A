"""LangGraph 에이전트의 기본 상태 스키마"""

from __future__ import annotations

from typing import Annotated, List, TypedDict

from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages


class BaseGraphInputState(TypedDict):
    """LangGraph 워크플로우의 기본 입력 상태"""

    messages: Annotated[List[BaseMessage], add_messages]


class BaseGraphState(BaseGraphInputState):
    """LangGraph 워크플로우의 기본 상태 (입력 + 내부 진행 상태 확장 시 상속)"""

    pass
