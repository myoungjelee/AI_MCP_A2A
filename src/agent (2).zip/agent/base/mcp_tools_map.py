"""서버별 허용 도구 목록과 선택 규칙 (fresh-first: financial_analysis 우선)"""

from __future__ import annotations

from typing import Dict, List

SERVER_TOOLS_ALLOWLIST: Dict[str, List[str]] = {
    "financial_analysis": [
        "get_financial_data",
        "calculate_financial_ratios",
        "perform_dcf_valuation",
        "generate_investment_report",
    ],
    "financedatareader": [
        "get_stock_basic_info",
        "get_stock_info",
        "get_stock_list",
        "get_daily_chart",
        "search_stock_by_name",
        "get_market_overview",
        "get_market_status",
    ],
    "stock_analysis": [
        "analyze_data_trends",
        "calculate_statistical_indicators",
        "perform_pattern_recognition",
    ],
    "naver_news": [
        "search_news_articles",
    ],
    "tavily_search": [
        "search_web",
    ],
    "macroeconomic": [
        "get_macro_series",
        "search_macro_series",
    ],
}


def select_servers_for_collection(question: str) -> List[str]:
    q = (question or "").lower()
    servers: List[str] = []

    # 0) 항상 financial_analysis를 최우선으로 추가 (fresh-first policy)
    servers.append("financial_analysis")

    # 1) 뉴스/웹
    if any(k in q for k in ("뉴스", "news", "헤드라인", "기사")):
        servers += ["naver_news", "tavily_search"]

    # 2) 거시
    if any(
        k in q for k in ("경기", "금리", "cpi", "ppi", "gdp", "실업", "macro", "거시")
    ):
        servers.append("macroeconomic")

    # 3) 주식/차트/기본정보
    servers += ["financedatareader", "stock_analysis"]

    # 중복 제거, 원순서 유지
    seen = set()
    out: List[str] = []
    for s in servers:
        if s not in seen:
            out.append(s)
            seen.add(s)
    return out


def select_tools_for_server(server: str, question: str) -> List[str]:
    q = (question or "").lower()
    allow = SERVER_TOOLS_ALLOWLIST.get(server, [])

    if server == "financial_analysis":
        tools = ["get_financial_data", "calculate_financial_ratios"]
        if any(k in q for k in ("가치", "valuation", "dcf", "밸류")):
            tools.append("perform_dcf_valuation")
        if any(k in q for k in ("리포트", "보고서", "report")):
            tools.append("generate_investment_report")
    elif server == "financedatareader":
        tools: List[str] = []
        if any(
            k in q for k in ("코드", "종목명", "티커", "ticker", "symbol", "리스트")
        ):
            tools += ["search_stock_by_name", "get_stock_list", "get_stock_basic_info"]
        if any(
            k in q for k in ("차트", "캔들", "가격", "봉", "chart", "price", "ohlc")
        ):
            tools += ["get_daily_chart", "get_stock_info"]
        if any(k in q for k in ("시장", "마켓", "status", "overview")):
            tools += ["get_market_status", "get_market_overview"]
        if not tools:
            tools = ["get_stock_basic_info", "get_stock_info"]
    elif server == "stock_analysis":
        tools = ["analyze_data_trends", "calculate_statistical_indicators"]
        if "패턴" in q or "pattern" in q:
            tools.append("perform_pattern_recognition")
    elif server == "naver_news":
        tools = ["search_news_articles"]
    elif server == "tavily_search":
        tools = ["search_web"]
    elif server == "macroeconomic":
        tools = ["search_macro_series", "get_macro_series"]
    else:
        tools = []

    # allowlist 필터 + 중복 제거
    allow_set = set(allow)
    filtered = [t for t in tools if t in allow_set] or allow[:1]
    seen: set[str] = set()
    deduped: List[str] = []
    for t in filtered:
        if t not in seen:
            deduped.append(t)
            seen.add(t)
    return deduped
