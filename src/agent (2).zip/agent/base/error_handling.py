"""에이전트 에러 처리 유틸"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


class AgentError(Exception):
    """에이전트 기본 에러"""


class AgentConfigurationError(AgentError):
    """설정 오류"""


class AgentExecutionError(AgentError):
    """실행 중 오류"""


class MCPConnectionError(AgentError):
    """MCP 연결 오류"""


class WorkflowError(AgentError):
    """그래프/워크플로우 오류"""


class ErrorHandler:
    """단순 에러 핸들러 (로깅 + 이력)"""

    def __init__(self) -> None:
        self.error_count: int = 0
        self.error_history: List[Dict[str, Any]] = []
        self.logger = logging.getLogger("agent.error_handler")

    async def handle_error(
        self, error: Exception, context: str = "unknown"
    ) -> Dict[str, Any]:
        self.error_count += 1
        info = {
            "context": context,
            "type": type(error).__name__,
            "message": str(error),
        }
        self.error_history.append(info)
        self.logger.error("Agent error", extra=info)
        return info
