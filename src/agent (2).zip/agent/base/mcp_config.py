"""MCP 서버 설정 및 연결 유틸리티"""

from __future__ import annotations

import os
from typing import Any, Dict

# 표준 포트 (docker-compose 기본과 일치하도록 시도)
DEFAULT_PORTS = {
    "macroeconomic": int(os.getenv("MACROECONOMIC_PORT", "8042")),
    "financial_analysis": int(os.getenv("FINANCIAL_ANALYSIS_PORT", "8040")),
    "stock_analysis": int(os.getenv("STOCK_ANALYSIS_PORT", "8052")),
    "naver_news": int(os.getenv("NAVER_NEWS_PORT", "8051")),
    "tavily_search": int(os.getenv("TAVILY_SEARCH_PORT", "8053")),
    # 키움 → FDR 교체
    "financedatareader": int(os.getenv("FINANCEDATAREADER_PORT", "8031")),
}

DEFAULT_HOST = os.getenv("MCP_SERVER_HOST", "localhost")


class MCPServerConfig:
    """MCP 서버 엔드포인트 로더"""

    @staticmethod
    def get_standard_servers() -> Dict[str, Dict[str, Any]]:
        servers: Dict[str, Dict[str, Any]] = {}
        # 환경변수 MCP_SERVERS=macroeconomic,financial_analysis,... 있으면 그 목록 우선
        raw = os.getenv("MCP_SERVERS", "")
        names = [n.strip() for n in raw.split(",") if n.strip()] or list(
            DEFAULT_PORTS.keys()
        )
        for name in names:
            port = DEFAULT_PORTS.get(name)
            if port is None:
                continue
            servers[name] = {
                "host": os.getenv(f"{name.upper()}_HOST", DEFAULT_HOST),
                "port": int(os.getenv(f"{name.upper()}_PORT", str(port))),
            }
        return servers
