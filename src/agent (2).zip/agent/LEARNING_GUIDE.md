# LangGraph 에이전트 개발 러닝 가이드

> **이 폴더는 LangGraph 기반의 AI 에이전트들을 담고 있습니다.** > **복잡한 워크플로우를 그래프 형태로 모델링하여 지능적인 처리를 수행합니다.**

---

## 📚 목차

1. [LangGraph 핵심 개념](#1-langgraph-핵심-개념)
2. [개발 순서와 학습 단계](#2-개발-순서와-학습-단계)
3. [통합 에이전트 상세 분석](#3-통합-에이전트-상세-분석)
4. [상태 관리 패턴](#4-상태-관리-패턴)
5. [실무 적용 포인트](#5-실무-적용-포인트)

---

## 1. LangGraph 핵심 개념

### 🧠 **LangGraph란 무엇인가?**

```python
# LangGraph의 기본 구조
from langgraph.graph import StateGraph
from typing import TypedDict

# 1. 상태 정의 (모든 데이터가 여기를 통과)
class AgentState(TypedDict):
    user_question: str          # 사용자 질문
    validation_result: Dict     # 검증 결과
    collected_data: List[Dict]  # 수집된 데이터
    analysis_result: Dict       # 분석 결과
    final_response: str         # 최종 응답
    current_step: str          # 현재 단계
    error_message: str         # 에러 메시지

# 2. 노드 함수 정의 (각 처리 단계)
async def validate_question(state: AgentState) -> AgentState:
    """질문 검증 노드"""
    # 상태를 받아서 처리하고 새로운 상태 반환
    validation = await verify_question(state["user_question"])
    return {"validation_result": validation, "current_step": "validated"}

# 3. 그래프 구성
workflow = StateGraph(AgentState)
workflow.add_node("validate", validate_question)
workflow.add_node("collect", collect_data)
workflow.add_node("analyze", analyze_data)

# 4. 흐름 정의
workflow.add_edge("validate", "collect")
workflow.add_edge("collect", "analyze")

# 🔍 핵심 특징:
# - 상태 기반: 모든 데이터가 중앙 상태를 통해 흐름
# - 그래프 구조: 복잡한 조건부 흐름 표현 가능
# - 타입 안전성: TypedDict로 상태 구조 명확화
# - 비동기 처리: 고성능 워크플로우 구현
```

### 🔄 **기존 방식 vs LangGraph**

```python
# ❌ 기존 방식: 단순 체인
async def old_style_processing(question: str):
    """기존의 순차적 처리 방식"""
    validation = await validate(question)
    if not validation["valid"]:
        return {"error": "Invalid question"}

    data = await collect_data(question)
    if not data:
        return {"error": "No data"}

    analysis = await analyze(data)
    return {"result": analysis}

# ✅ LangGraph 방식: 상태 기반 그래프
class SmartAgentState(TypedDict):
    question: str
    validation: Dict
    data: List
    analysis: Dict
    retry_count: int

async def smart_validate(state: SmartAgentState) -> SmartAgentState:
    """지능적 검증 - 재시도 로직 포함"""
    validation = await validate_with_retry(state["question"])
    return {
        **state,
        "validation": validation,
        "current_step": "validation_complete"
    }

def route_after_validation(state: SmartAgentState) -> str:
    """조건부 라우팅"""
    if state["validation"]["valid"]:
        return "collect_data"
    elif state.get("retry_count", 0) < 3:
        return "retry_validation"
    else:
        return "error_handler"

# 🔍 LangGraph 장점:
# 1. 복잡한 조건부 흐름 쉽게 구현
# 2. 에러 발생 시 적절한 경로로 복구
# 3. 상태 추적으로 디버깅 용이
# 4. 병렬 처리 및 최적화 가능
```

---

## 2. 개발 순서와 학습 단계

### 📅 **Phase 1: 기본 구조 이해 (1주)**

#### **2.1 Base Graph Agent 분석**

```python
# base/base_graph_agent.py - 모든 에이전트의 기반
class BaseGraphAgent:
    """모든 LangGraph 에이전트의 기본 클래스"""

    def __init__(self, agent_name: str):
        self.agent_name = agent_name
        self.logger = setup_logger(agent_name)

        # LLM 초기화 (Ollama)
        self.llm = ChatOllama(
            model=os.getenv("LLM_MODEL", "gpt-oss:20b"),
            base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
            temperature=0.7
        )

        # 그래프 초기화
        self.workflow = None
        self.graph = None

    def build_graph(self) -> StateGraph:
        """자식 클래스에서 구현해야 하는 그래프 빌드 메서드"""
        raise NotImplementedError("Subclass must implement build_graph")

    async def run(self, initial_state: Dict[str, Any]) -> Dict[str, Any]:
        """그래프 실행"""
        if not self.graph:
            self.workflow = self.build_graph()
            self.graph = self.workflow.compile()

        try:
            # 그래프 실행
            final_state = await self.graph.ainvoke(initial_state)
            return final_state

        except Exception as e:
            self.logger.error(f"그래프 실행 실패: {e}")
            return {"error": str(e), "status": "failed"}

# 🔍 학습 포인트:
# 1. 모든 에이전트가 공유하는 기본 구조
# 2. LLM과의 통합 방법
# 3. 그래프 컴파일과 실행 과정
```

#### **2.2 상태 정의의 중요성**

```python
# base/base_graph_state.py - 상태 설계 패턴
from typing import TypedDict, List, Dict, Any, Optional

class BaseAgentState(TypedDict):
    """모든 에이전트가 공유하는 기본 상태"""

    # 필수 필드
    agent_id: str
    session_id: str
    timestamp: str
    current_step: str

    # 옵션 필드
    error_message: Optional[str]
    retry_count: Optional[int]
    metadata: Optional[Dict[str, Any]]

class InvestmentAgentState(BaseAgentState):
    """투자 관련 에이전트의 확장 상태"""

    # 입력 데이터
    user_question: str

    # 처리 단계별 데이터
    validation_result: Optional[Dict[str, Any]]
    collected_data: Optional[List[Dict[str, Any]]]
    analysis_result: Optional[Dict[str, Any]]

    # 출력 데이터
    final_response: Optional[str]
    confidence_score: Optional[float]

# 🔍 상태 설계 원칙:
# 1. TypedDict로 타입 안전성 확보
# 2. Optional 필드로 단계별 진행 표현
# 3. 계층적 상속으로 재사용성 증대
# 4. 명확한 네이밍으로 가독성 향상
```

### 📅 **Phase 2: 통합 에이전트 심화 (2-3주)**

#### **2.3 노드 함수 패턴**

```python
# integrated_agent/nodes.py - 핵심 노드 구현
class IntegratedAgentNodes:
    """통합 에이전트의 모든 노드 함수들"""

    def __init__(self, model_name: str = "gpt-oss:20b"):
        self.llm = ChatOllama(model=model_name)
        self.mcp_client = MultiServerMCPClient()
        self.validator = InvestmentQuestionValidator()

    async def validate_question_node(
        self,
        state: IntegratedAgentState
    ) -> IntegratedAgentState:
        """
        질문 검증 노드

        역할: 사용자 질문이 투자 관련인지 LLM으로 검증
        """
        try:
            # LLM에게 질문 분석 요청
            validation_prompt = f"""
            다음 질문이 투자나 금융과 관련된지 판단해주세요:

            질문: {state['user_question']}

            JSON 형태로 응답해주세요:
            {{
                "is_investment_related": true/false,
                "confidence": 0.0-1.0,
                "category": "주식/경제/뉴스/일반",
                "suggested_keywords": ["키워드1", "키워드2"],
                "reason": "판단 근거"
            }}
            """

            response = await self.llm.ainvoke(validation_prompt)
            validation_result = json.loads(response.content)

            # 상태 업데이트
            return {
                **state,
                "validation_result": validation_result,
                "current_step": "validation_complete",
                "timestamp": datetime.now().isoformat()
            }

        except Exception as e:
            self.logger.error(f"질문 검증 실패: {e}")
            return {
                **state,
                "error_message": f"질문 검증 중 오류: {e}",
                "current_step": "validation_failed"
            }

    async def collect_data_node(
        self,
        state: IntegratedAgentState
    ) -> IntegratedAgentState:
        """
        데이터 수집 노드

        역할: 여러 MCP 서버에서 병렬로 데이터 수집
        """
        if not state["validation_result"]["is_investment_related"]:
            return {
                **state,
                "error_message": "투자 관련 질문이 아닙니다",
                "current_step": "collection_skipped"
            }

        try:
            # 질문 카테고리에 따른 MCP 서버 선택
            category = state["validation_result"]["category"]
            keywords = state["validation_result"]["suggested_keywords"]

            # 병렬 데이터 수집 작업 정의
            collection_tasks = []

            if category in ["주식", "경제"]:
                collection_tasks.extend([
                    self._collect_stock_data(keywords),
                    self._collect_economic_data(keywords),
                    self._collect_financial_analysis(keywords)
                ])

            if category in ["뉴스", "주식"]:
                collection_tasks.append(
                    self._collect_news_data(keywords)
                )

            # 항상 검색 데이터도 수집
            collection_tasks.append(
                self._collect_search_data(keywords)
            )

            # 병렬 실행
            self.logger.info(f"데이터 수집 시작: {len(collection_tasks)}개 작업")
            results = await asyncio.gather(*collection_tasks, return_exceptions=True)

            # 성공한 결과만 수집
            collected_data = []
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    self.logger.warning(f"데이터 수집 {i} 실패: {result}")
                else:
                    collected_data.append(result)

            return {
                **state,
                "collected_data": collected_data,
                "current_step": "collection_complete",
                "timestamp": datetime.now().isoformat()
            }

        except Exception as e:
            self.logger.error(f"데이터 수집 실패: {e}")
            return {
                **state,
                "error_message": f"데이터 수집 중 오류: {e}",
                "current_step": "collection_failed"
            }

# 🔍 노드 함수 패턴:
# 1. 항상 상태를 받아서 상태를 반환
# 2. 예외 처리로 그래프 전체 실패 방지
# 3. 로깅으로 디버깅 정보 제공
# 4. 타임스탬프로 진행 상황 추적
```

---

## 3. 통합 에이전트 상세 분석

### 🎯 **전체 워크플로우**

```python
# integrated_agent/agent.py - 메인 에이전트 구현
class IntegratedAgent(BaseGraphAgent):
    """통합 AI 에이전트 - 모든 MCP 서버를 활용"""

    def build_graph(self) -> StateGraph:
        """복잡한 투자 분석 워크플로우 구축"""

        workflow = StateGraph(IntegratedAgentState)

        # 노드 추가
        workflow.add_node("validate_question", self.nodes.validate_question_node)
        workflow.add_node("collect_data", self.nodes.collect_data_node)
        workflow.add_node("analyze_data", self.nodes.analyze_data_node)
        workflow.add_node("generate_response", self.nodes.generate_response_node)
        workflow.add_node("handle_error", self.nodes.handle_error_node)

        # 시작점 설정
        workflow.set_entry_point("validate_question")

        # 조건부 라우팅 설정
        workflow.add_conditional_edges(
            "validate_question",
            self._route_after_validation,
            {
                "proceed": "collect_data",
                "invalid": "handle_error",
                "retry": "validate_question"
            }
        )

        workflow.add_conditional_edges(
            "collect_data",
            self._route_after_collection,
            {
                "analyze": "analyze_data",
                "insufficient": "handle_error",
                "retry": "collect_data"
            }
        )

        workflow.add_edge("analyze_data", "generate_response")
        workflow.add_edge("handle_error", END)
        workflow.add_edge("generate_response", END)

        return workflow

    def _route_after_validation(self, state: IntegratedAgentState) -> str:
        """검증 후 라우팅 결정"""

        if state.get("error_message"):
            return "invalid"

        validation = state.get("validation_result", {})

        if not validation.get("is_investment_related", False):
            return "invalid"

        if validation.get("confidence", 0) < 0.7:
            retry_count = state.get("retry_count", 0)
            if retry_count < 2:
                return "retry"
            else:
                return "invalid"

        return "proceed"

    def _route_after_collection(self, state: IntegratedAgentState) -> str:
        """데이터 수집 후 라우팅 결정"""

        if state.get("error_message"):
            return "insufficient"

        collected_data = state.get("collected_data", [])

        if len(collected_data) == 0:
            retry_count = state.get("retry_count", 0)
            if retry_count < 2:
                return "retry"
            else:
                return "insufficient"

        return "analyze"

# 🔍 그래프 설계 원칙:
# 1. 명확한 노드 책임 분리
# 2. 조건부 라우팅으로 지능적 흐름 제어
# 3. 재시도 로직으로 복원력 확보
# 4. 에러 핸들링으로 안정성 보장
```

### 🔄 **조건부 라우팅의 힘**

```python
# 복잡한 비즈니스 로직을 간단하게 표현
def intelligent_routing(state: IntegratedAgentState) -> str:
    """지능적 라우팅 - 상황에 따라 최적 경로 선택"""

    # 1. 에러 상황 체크
    if state.get("error_message"):
        error_type = classify_error(state["error_message"])
        if error_type == "recoverable":
            return "retry_with_backoff"
        else:
            return "escalate_to_human"

    # 2. 데이터 품질 체크
    data_quality = assess_data_quality(state.get("collected_data", []))
    if data_quality["score"] < 0.6:
        if data_quality["reason"] == "insufficient":
            return "collect_more_data"
        elif data_quality["reason"] == "outdated":
            return "refresh_data"
        else:
            return "proceed_with_warning"

    # 3. 사용자 컨텍스트 고려
    user_context = state.get("user_context", {})
    if user_context.get("experience_level") == "beginner":
        return "simple_analysis"
    elif user_context.get("risk_tolerance") == "conservative":
        return "detailed_risk_analysis"
    else:
        return "standard_analysis"

# 🔍 라우팅의 활용:
# 1. 에러 복구 전략 구현
# 2. 데이터 품질에 따른 처리 방식 변경
# 3. 사용자 맞춤형 경험 제공
# 4. 비즈니스 규칙의 코드화
```

---

## 4. 상태 관리 패턴

### 💾 **상태 업데이트 전략**

```python
# 올바른 상태 업데이트 패턴
async def proper_state_update(state: IntegratedAgentState) -> IntegratedAgentState:
    """올바른 상태 업데이트 방법"""

    try:
        # 처리 로직
        new_data = await process_something()

        # ✅ 올바른 방법: 전체 상태 유지하며 업데이트
        return {
            **state,  # 기존 상태 모두 보존
            "new_field": new_data,
            "current_step": "processing_complete",
            "timestamp": datetime.now().isoformat(),
            "metadata": {
                **state.get("metadata", {}),  # 기존 메타데이터 보존
                "last_update": "process_something"
            }
        }

    except Exception as e:
        # ❌ 잘못된 방법: 기존 상태 손실
        # return {"error": str(e)}  # 다른 모든 데이터 손실!

        # ✅ 올바른 방법: 에러 상황에서도 상태 보존
        return {
            **state,
            "error_message": str(e),
            "current_step": "processing_failed",
            "retry_count": state.get("retry_count", 0) + 1
        }

# 상태 추적 도우미 함수들
def track_progress(state: IntegratedAgentState, step_name: str) -> IntegratedAgentState:
    """진행 상황 추적"""
    progress_history = state.get("progress_history", [])
    progress_history.append({
        "step": step_name,
        "timestamp": datetime.now().isoformat(),
        "duration": calculate_step_duration(state)
    })

    return {
        **state,
        "current_step": step_name,
        "progress_history": progress_history
    }

def validate_state_integrity(state: IntegratedAgentState) -> bool:
    """상태 무결성 검증"""
    required_fields = ["agent_id", "session_id", "current_step"]

    for field in required_fields:
        if field not in state:
            logger.error(f"필수 상태 필드 누락: {field}")
            return False

    return True

# 🔍 상태 관리 원칙:
# 1. 항상 전체 상태 보존 (spread operator 사용)
# 2. 에러 상황에서도 기존 데이터 유지
# 3. 진행 상황 추적으로 디버깅 용이
# 4. 상태 무결성 검증으로 안정성 확보
```

### 🔄 **병렬 처리와 상태**

```python
# 병렬 처리에서의 상태 관리
async def parallel_processing_node(state: IntegratedAgentState) -> IntegratedAgentState:
    """병렬 처리가 포함된 노드"""

    async def task_with_state_update(task_name: str, task_func: Callable):
        """개별 작업 수행 후 부분 상태 반환"""
        try:
            result = await task_func()
            return {
                "success": True,
                "task_name": task_name,
                "result": result,
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "success": False,
                "task_name": task_name,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }

    # 병렬 작업 정의
    tasks = [
        task_with_state_update("stock_analysis", analyze_stocks),
        task_with_state_update("news_collection", collect_news),
        task_with_state_update("market_data", fetch_market_data)
    ]

    # 병렬 실행
    task_results = await asyncio.gather(*tasks, return_exceptions=True)

    # 결과 통합
    successful_tasks = [r for r in task_results if r.get("success")]
    failed_tasks = [r for r in task_results if not r.get("success")]

    # 통합된 결과로 상태 업데이트
    return {
        **state,
        "parallel_results": {
            "successful_count": len(successful_tasks),
            "failed_count": len(failed_tasks),
            "results": successful_tasks,
            "errors": failed_tasks
        },
        "current_step": "parallel_processing_complete",
        "timestamp": datetime.now().isoformat()
    }

# 🔍 병렬 처리 패턴:
# 1. 각 작업의 성공/실패 독립적 처리
# 2. 부분 실패 허용으로 전체 작업 계속
# 3. 결과 통합으로 일관된 상태 유지
# 4. 상세한 로깅으로 디버깅 지원
```

---

## 5. 실무 적용 포인트

### 🚀 **성능 최적화**

```python
# 성능 최적화된 LangGraph 에이전트
class OptimizedIntegratedAgent(BaseGraphAgent):
    """성능 최적화된 통합 에이전트"""

    def __init__(self, agent_name: str = "optimized_integrated"):
        super().__init__(agent_name)

        # 캐싱 레이어
        self.state_cache = TTLCache(maxsize=1000, ttl=300)
        self.result_cache = TTLCache(maxsize=500, ttl=600)

        # 비동기 세마포어로 동시 실행 제한
        self.processing_semaphore = asyncio.Semaphore(10)

        # 메트릭 수집
        self.performance_metrics = PerformanceCollector()

    async def run_with_caching(self, initial_state: Dict[str, Any]) -> Dict[str, Any]:
        """캐싱이 적용된 그래프 실행"""

        # 캐시 키 생성
        cache_key = self._generate_cache_key(initial_state)

        # 캐시 확인
        if cached_result := self.result_cache.get(cache_key):
            self.performance_metrics.record_cache_hit()
            return cached_result

        # 세마포어로 동시 실행 제한
        async with self.processing_semaphore:
            start_time = time.time()

            try:
                # 실제 그래프 실행
                result = await self.run(initial_state)

                # 성능 메트릭 기록
                execution_time = time.time() - start_time
                self.performance_metrics.record_execution(
                    agent_name=self.agent_name,
                    execution_time=execution_time,
                    state_size=len(str(initial_state)),
                    result_size=len(str(result))
                )

                # 결과 캐싱 (성공한 경우만)
                if not result.get("error"):
                    self.result_cache[cache_key] = result

                return result

            except Exception as e:
                self.performance_metrics.record_error(
                    agent_name=self.agent_name,
                    error_type=type(e).__name__,
                    execution_time=time.time() - start_time
                )
                raise

    def _generate_cache_key(self, state: Dict[str, Any]) -> str:
        """상태 기반 캐시 키 생성"""
        # 캐시에 영향을 주는 필드만 선택
        cache_relevant = {
            "question": state.get("user_question", ""),
            "context": state.get("user_context", {}),
            "timestamp_hour": datetime.now().strftime("%Y%m%d%H")  # 시간 단위로 캐시
        }

        return hashlib.md5(json.dumps(cache_relevant, sort_keys=True).encode()).hexdigest()

# 🔍 성능 최적화 포인트:
# 1. 결과 캐싱으로 중복 처리 방지
# 2. 세마포어로 리소스 사용량 제어
# 3. 메트릭 수집으로 성능 모니터링
# 4. 시간 기반 캐시로 데이터 신선도 유지
```

### 🔧 **프로덕션 고려사항**

```python
# 프로덕션 환경용 에이전트
class ProductionIntegratedAgent(OptimizedIntegratedAgent):
    """프로덕션 환경에 최적화된 에이전트"""

    def __init__(self, agent_name: str = "production_integrated"):
        super().__init__(agent_name)

        # 서킷 브레이커
        self.circuit_breaker = CircuitBreaker(
            failure_threshold=5,
            recovery_timeout=60
        )

        # 상태 영속화
        self.state_store = StateStore(
            backend=os.getenv("STATE_STORE_BACKEND", "redis"),
            connection_string=os.getenv("STATE_STORE_URL")
        )

        # 메트릭 export
        self.metrics_exporter = MetricsExporter(
            endpoint=os.getenv("METRICS_ENDPOINT"),
            service_name=agent_name
        )

    async def run_with_persistence(
        self,
        initial_state: Dict[str, Any],
        session_id: str
    ) -> Dict[str, Any]:
        """상태 영속화가 적용된 실행"""

        try:
            # 이전 상태 복원 (중단된 세션 처리)
            restored_state = await self.state_store.get_state(session_id)
            if restored_state:
                self.logger.info(f"세션 {session_id} 상태 복원됨")
                initial_state = {**restored_state, **initial_state}

            # 서킷 브레이커 적용
            @self.circuit_breaker
            async def protected_execution():
                return await self.run_with_caching(initial_state)

            # 실행
            result = await protected_execution()

            # 최종 상태 저장
            await self.state_store.save_state(session_id, result)

            # 메트릭 전송
            await self.metrics_exporter.export_metrics()

            return result

        except CircuitBreakerError:
            # 서킷 브레이커 열림
            self.logger.warning("서킷 브레이커 활성화 - 서비스 일시 중단")
            return {
                "error": "서비스가 일시적으로 이용할 수 없습니다",
                "retry_after": 60,
                "status": "circuit_breaker_open"
            }

        except Exception as e:
            # 예상치 못한 오류
            self.logger.error(f"에이전트 실행 실패: {e}")

            # 부분 상태라도 저장 (복구를 위해)
            if "current_step" in initial_state:
                await self.state_store.save_partial_state(session_id, initial_state)

            return {
                "error": "시스템 오류가 발생했습니다",
                "session_id": session_id,
                "recoverable": True,
                "status": "system_error"
            }

# 🔍 프로덕션 고려사항:
# 1. 서킷 브레이커로 장애 전파 방지
# 2. 상태 영속화로 중단된 작업 복구
# 3. 메트릭 수집으로 운영 모니터링
# 4. 우아한 실패 처리로 사용자 경험 향상
```

---

## 💡 **다음 단계 학습 가이드**

### 📈 **학습 로드맵**

#### **1단계: 기초 마스터 (1-2주)**

```
✅ 해야 할 것:
1. StateGraph 기본 구조 이해
2. 간단한 노드 함수 작성
3. 조건부 라우팅 구현
4. 로컬 환경에서 테스트

📚 참고 자료:
- docs/langgraph-llms_0.6.2.txt
- 기존 integrated_agent 코드 분석
```

#### **2단계: 실무 적용 (3-4주)**

```
✅ 해야 할 것:
1. 복잡한 비즈니스 로직 구현
2. 병렬 처리 패턴 적용
3. 에러 복구 전략 구현
4. 성능 최적화 기법 적용

🛠️ 실습 프로젝트:
- 새로운 도메인의 에이전트 개발
- 기존 에이전트 기능 확장
```

#### **3단계: 고급 활용 (5주 이상)**

```
✅ 해야 할 것:
1. 프로덕션 환경 배포
2. 모니터링 시스템 구축
3. A/B 테스트 구현
4. 스케일링 전략 수립

🚀 발전 방향:
- 멀티 에이전트 시스템
- 실시간 스트리밍 처리
- 사용자 맞춤형 워크플로우
```

이 가이드를 통해 **LangGraph 기반 AI 에이전트 개발의 전문가**가 되실 수 있습니다! 🎯
